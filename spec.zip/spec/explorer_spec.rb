require File.dirname(__FILE__)+'/spec_helper'
require 'fake_mingle'

require 'ThoughtWorks.VisualStudio.dll'
require 'ThoughtWorksMingleLib.dll'
require 'C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.0/System.Security.dll'

include ThoughtWorks::VisualStudio
include ThoughtWorksMingleLib
include System::Security

describe 'explorer view model' do
    before(:all) do
        run_fake_mingle
    end
    
    before do
        @pw = SecureString.new
        string = System::String.new("secret")
        string.ToCharArray.each {|c| @pw.AppendChar(c)}
        @vm = ExplorerViewModel.new("http://localhost:9123", "mingleuser", @pw)
    end
    it 'should count the projects' do
        @vm.project_list.count.should == 2
    end
    
    it 'should count the favorites' do
        @vm.current_project_id = 'test'
        @vm.favorite_list.count.should == 15
    end
    
    it 'should count the team members' do
        @vm.current_project_id = 'test'
        @vm.team_members_list.count.should == 2
    end
    
    it 'should count the cards for the favorite' do
        @vm.current_project_id = 'test'
        @vm.get_cards_from_favorite('Sprint List').count.should == 78
    end

end

def run_fake_mingle
    Sinatra::Application.fork! :host => 'localhost', :port => 9123 
end