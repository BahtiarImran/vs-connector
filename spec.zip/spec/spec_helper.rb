$LOAD_PATH << File.dirname(__FILE__) + '/../build'

require 'rubygems'
require 'sinatra/base'

class Sinatra::Base
    def self.fork!(options={})
       app = Thread.new { run! options }
        # wait for it...
        while(app.status != 'sleep') do end
    end
end

class String
    def to_xml
        System::Xml::Linq::XElement.parse self
    end
end

def BreakHere
    System::Diagnostics::Debugger.Break()
end

def LOG(message)
    puts "\n***********\n" + message + "\n**********\n"
end

def IN_PROGRESS
    begin
        yield
        raise "Unexpected success"
        rescue Spec::Expectations::ExpectationNotMetError
    end
end
