def fake_project
<<-PROJECT
  <project> 
    <name>test</name> 
    <identifier>test</identifier> 
    <description> 
    </description> 
    <created_at type="datetime">2011-08-12T17:59:34Z</created_at> 
    <updated_at type="datetime">2011-08-12T17:59:42Z</updated_at> 
    <created_by url="http://localhost:8080/api/v2/users/1.xml"> 
      <name>Mark Richter</name> 
      <login>mrichter</login> 
    </created_by> 
    <modified_by url="http://localhost:8080/api/v2/users/1.xml"> 
      <name>Mark Richter</name> 
      <login>mrichter</login> 
    </modified_by> 
    <keywords> 
      <keyword>card</keyword> 
      <keyword>#</keyword> 
    </keywords> 
    <template nil="true"></template> 
    <email_address> 
    </email_address> 
    <email_sender_name> 
    </email_sender_name> 
    <date_format>%d %b %Y</date_format> 
    <time_zone>Arizona</time_zone> 
    <precision type="integer">2</precision> 
    <anonymous_accessible type="boolean">false</anonymous_accessible> 
    <auto_enroll_user_type nil="true"></auto_enroll_user_type> 
  </project> 
PROJECT
end
