class FakeExplorer
    require '/lib/ThoughtWorksMingleLib.dll'
    include ThoughtWorksMingleLib
    
    def Model
        @model
    end
    
    def projects
        return @projects
    end
    
    def team_members
        return @team_members
    end
    
    def initialize(model)
        @model = model
        @pw = System::Security::SecureString.new
        string = System::String.new("secret")
        string.ToCharArray.each {|c| @pw.AppendChar(c)}
    end
    
    def click_refresh
        mingle = MingleServer.new("http://localhost:9123", "mingleuser", @pw)
        @projects = refresh_projects
        #@team_members = refresh_team_members
    end
    
    def refresh_projects(mingle)
        @projects = @model.projects.get()
    end
    
    def refresh_team_members(mingle)
        project = new MingleProject("test", mingle)
        project.GetTeam().ToList.each {|p| }
    end
end
