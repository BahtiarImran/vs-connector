require File.dirname(__FILE__)+'/spec_helper'
require 'ThoughtWorks.VisualStudio.dll'
include ThoughtWorks::VisualStudio
include System::Security

describe 'settings' do
    before do
        @model = SettingsModel.new
        @model.mingle_host = 'test host'
        @model.save
        @model.reload
    end 
    it 'should get mingle_host' do
        @model.mingle_host.should == 'test host'
    end
    it 'should get mingle_password' do
        ss = System::Security::SecureString.new
        string = System::String.new("thepassword")
        string.ToCharArray.each {|c| ss.AppendChar(c)}
        @model = SettingsModel.new
        @model.mingle_password = ss
        @model.save
        @model.reload
        @model.mingle_password.should == ss
    end
    it 'should get the mingle_login' do
        @model.mingle_login = "mingleuser"
        @model.save
        @model.reload
        @model.mingle_login.should == "mingleuser"
    end
    it 'should get the mingle_project_id' do
        @model.mingle_project_id = "project"
        @model.save
        @model.reload
        @model.mingle_project_id.should == "project"
    end
    it 'should get the go_login' do
        @model.go_login = "go_login"
        @model.save
        @model.reload
        @model.go_login.should == "go_login"
    end
    it 'should get mingle_password' do
        ss = System::Security::SecureString.new
        string = System::String.new("thepassword")
        string.ToCharArray.each {|c| ss.AppendChar(c)}
        @model = SettingsModel.new
        @model.go_password = ss
        @model.save
        @model.reload
        @model.go_password.should == ss
    end
    it 'should get the go_host' do
        @model.go_host = "go_host"
        @model.save
        @model.reload
        @model.go_host.should == "go_host"
    end
    it 'should get the trace' do
        @model.trace = true
        @model.save
        @model.reload
        @model.trace.should == true
    end
    it 'should get the trace' do
        @model.trace_log = "log.log"
        @model.save
        @model.reload
        @model.trace_log.should == "log.log"
        @model.trace_log = ""
        @model.trace_log.length.should == 0
    end
end
